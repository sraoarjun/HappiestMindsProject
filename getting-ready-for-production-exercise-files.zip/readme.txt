In order to use these demos you will need to download the packages.

For the visual studio projects, in order to get them to run, you will need to enable automatic nuget package downloading. In Visual Studio, go to 
Tools | Options | Package Manager | General
And check "Allow NuGet to download missing packages during build", then just compile the project.

To get grunt to work, you will need to install the packages by opening up a command prompt in the jsbuild directory, and run "npm install". If you are completely uncomfortable with node, please see Pluralsight's course on node.