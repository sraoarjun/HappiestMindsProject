module.exports = function(grunt) {
	grunt.initConfig({
						
	});
	
	grunt.registerTask('default', ['']);
	
	
};