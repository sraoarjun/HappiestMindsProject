angular.module('app').value('scFollowedInstructors', [
  {
    id: 1,
    name: 'Professor Snape'
  },
  {
    id: 2,
    name: 'Professor McGonagall'
  },
  {
    id: 3,
    name: 'Professor Dumbledore'
  }
]);